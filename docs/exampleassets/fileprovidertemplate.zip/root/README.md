# Please make sure to modify the servername and keep the qoutes marks "" 
	- under the info.json file in the Root Folder


# Please make sure to update the updateepoch and make sure to delete the previous numbers

	# If your having trouble finding current epoch please visit
		- https://www.epochconverter.com/